# Security Audit

## Content Security Policy (CSP)

Two independent, concrete defects found in the CSP, both confirmed via verbatim console text:

1. **`img-src` missing `media.kitsu.app`** — see **F-04**. Allowlist observed: `'self' https://image.tmdb.org https://s4.anilist.co https://img.youtube.com https://via.placeholder.com data: blob:`. This is a *missing entry*, not an injection risk — the practical effect is broken images (see Findings), not a security hole, but it's grouped here because it's the same policy object as the item below.
2. **`frame-src` contains invalid wildcard syntax** — see **F-09**. `https://cf.*.site` and `https://*.vidsrc.*` are not valid CSP source-expression syntax (mid-domain wildcards aren't supported; only a leading `*.` for subdomains is). Browsers silently drop malformed entries rather than erroring, so these two intended allowances are not actually enforced as written. This is a policy-authoring bug rather than an exploitable gap by itself, but it means the *actual* effective frame-src is narrower than intended — worth fixing for both correctness and to avoid a false sense of the policy being more permissive/restrictive than it really is.

Neither defect was found to allow anything a tighter, correctly-written CSP wouldn't also need to allow (i.e., no evidence of an overly-broad `*` at the top level, no `unsafe-inline`/`unsafe-eval` observed in script-src during this pass — though script-src itself was not exhaustively enumerated).

## Iframe sandboxing

**Not checked this pass.** Inspecting the `sandbox` attribute on the video-embed `<iframe>` elements requires DOM-source inspection that wasn't performed as a dedicated step. Given the trust/safety findings around embed sources (F-02, F-14), this is a reasonable follow-up: if these iframes aren't sandboxed (or are sandboxed but with `allow-top-navigation` present), that would materially explain how a redirect ad (F-02) is able to attempt a top-level navigation at all. Marked **N/A (not attempted — see env.md)** in the checklist.

## Response headers (HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy)

**Not checked this pass.** The browser automation tooling used exposes navigation status codes and console-visible policy violations, but not raw response headers. No `curl`/header-inspection tool was available in this environment. Marked **N/A (tool not available — see env.md)**.

## Cookies

**Not checked this pass in detail.** The site's own Privacy Policy discloses Supabase-based auth (consistent with `sb-access-token`/`sb-refresh-token`-style cookies being used, per Supabase's standard client library behavior) — this is the site's own disclosure, not something extracted from cookie inspection. Actual cookie flags (`Secure`, `HttpOnly`, `SameSite`) were not directly inspected this pass, since doing so meaningfully would require either DevTools-level cookie inspection or a logged-in session to see the auth cookies specifically (out of scope per constraint #1 in `env.md`). Marked **N/A (requires login and/or tooling not available)**.

## `/api/health` — unauthenticated infrastructure disclosure

See **F-15** for the full finding. Summary: an unauthenticated GET returns the exact Supabase project hostname, the exact Upstash Redis instance hostname, TMDB integration status, and embed-provider live-count — more detail than a public health-check endpoint conventionally exposes. No credential values were exposed. Severity: **Medium**.

## Other API endpoints

`/api/health` and `/api/search` were the only two endpoints exercised directly with adversarial/edge-case input (missing params, etc.) — see `route-matrix.csv` for the full list of endpoints named in the spec that were **not** exercised this pass, most of which require an authenticated session and were out of scope per the no-login constraint. None of the endpoints tested returned stack traces, verbose framework error pages, or any other secondary information disclosure beyond the `/api/health` finding above.

## Third-party embed trust

Covered in `findings.md` as functional/trust findings rather than pure security findings, but worth flagging here too: at least one embed source (VidSrc IO) attempted to redirect to an unrelated, unexplained domain (`cloudorchestranova.com`) on click (**F-02**), and the default source's player surfaced an ad overlay styled to mimic a system security prompt (**F-14**). Neither was followed through (per the rules of engagement — no unknown domains were granted access), so the ultimate destination/payload of the `cloudorchestranova.com` redirect was not characterized further. If this matters, a follow-up specifically dedicated to walking every source in the dropdown, in a disposable/sandboxed browser profile, and recording exactly what each one attempts, would be the right next step.

## Injected-instruction check

Per the rules of engagement, all page/embed/ad/API content was treated as data, never as instructions, throughout this audit. One overlay (F-14, the fake "Connect to VPN Protection" prompt) is worth flagging again here specifically because it's the one piece of content encountered that was *styled* to look like a system-level instruction/prompt to the end user — no content was found that appeared to be specifically targeting an AI agent (e.g. hidden text instructing a crawler/automation tool to take some action), but this fake-system-prompt pattern is exactly the shape of thing that rule exists to guard against, so it's called out explicitly rather than filed only under UX.
