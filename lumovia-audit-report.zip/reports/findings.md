# Lumovia — Findings

Ordered most-severe first. Severity guide: **Critical** = site/feature completely broken or unsafe for a large share of users; **High** = major feature broken or a real trust/safety issue, but with a workaround; **Medium** = a real bug with clear user impact, workaround exists; **Low** = cosmetic, minor, or edge-case.

---

### F-01 — `/genres` returns a hard HTTP 500
**Severity:** Critical
**Area:** Routing / server
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/genres`
**Repro:** Navigate directly to `/genres` (it's in the sitemap at priority 0.7, and is where a working "All Genres"-type link would be expected to point).
**Expected:** The genre-directory page renders (or, if it doesn't exist, a clean styled 404).
**Actual:** The server returns HTTP 500. The rendered output is a bare, unstyled "Internal Server Error" string on a black background — no Lumovia nav/footer/chrome at all, i.e. this is the raw framework crash page, not a custom error page.
**Evidence:** Network log: `GET https://cache-proxy.zainrana553.workers.dev/genres → 500`.
**Suggested fix:** Find and fix the server-side error on this route; add a styled fallback error boundary so a future regression here doesn't show raw crash output. Since this URL is sitemap-submitted, also expect this to show up as a crawl error in Search Console.

---

### F-02 — Video source "VidSrc IO" leads to an unrelated redirect domain (`cloudorchestranova.com`)
**Severity:** High
**Area:** Video player / trust & safety
**URL(s):** TV detail page (Breaking Bad), source dropdown → "VidSrc IO (T2)"
**Repro:** Open a TV episode, switch the source dropdown to "VidSrc IO (T2)", click the play button on the resulting thumbnail.
**Expected:** The video begins playing inline, same as the default VidCore source.
**Actual:** Clicking play attempts to open `cloudorchestranova.com` — a domain with no stated relationship to VidSrc or any labeled provider. This is the classic signature of a pop-under/redirect ad riding along inside a third-party embed. Testing was stopped at this point (access to the unknown domain was declined) rather than following the redirect through.
**Evidence:** Browser access-request prompt for `cloudorchestranova.com` triggered by the click; declined.
**Suggested fix:** Audit which of the ~10 embed sources in the dropdown do this, and either drop them or put a clear "third-party, use at your own risk" label on sources you haven't personally verified are redirect-free.

---

### F-03 — Anime video player: both sources tried render fully black, nothing plays
**Severity:** High
**Area:** Video player (anime)
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/anime/demon-slayer-kimetsu-no-yaiba-2019-100038000`
**Repro:** Open the title, click "Play Episode 1". Try the default source ("Cinezo Anime (Dub) (T1) [98%]"), then try "2Embed Anime (T2) [90%]".
**Expected:** Playback starts within a couple of seconds, as reliably observed for movie/TV titles on the default "VidCore" source.
**Actual:** Both sources render a fully black player — no thumbnail, no controls, no progress movement, 0:00 — and never recover, even after several seconds.
**Evidence:** Direct observation on two independent source selections; contrasted against working movie/TV playback in the same session.
**Suggested fix:** The anime embed pipeline (Cinezo/2Embed/AniList-Kitsu integration) needs its own smoke test — it appears to be broken independently of, but alongside, the CSP image-loading gap (F-04) that also only affects anime content. Worth checking whether the remaining 2 anime sources (Cinezo Sub, VidSrc CC Anime) and other anime titles have the same problem.

---

### F-04 — CSP `img-src` is missing `media.kitsu.app` — blocks anime poster/backdrop images site-wide
**Severity:** High
**Area:** Content Security Policy / images
**URL(s):** Site-wide, most visible on `/about`, homepage anime rows, `/anime/*`, Animation-genre titles
**Repro:** Load any page that renders an anime title sourced from Kitsu/AniList (e.g. `/about`, which embeds an anime carousel).
**Expected:** Anime posters/covers render normally.
**Actual:** The site's own CSP `img-src` allowlist is: `'self' https://image.tmdb.org https://s4.anilist.co https://img.youtube.com https://via.placeholder.com data: blob:`. `media.kitsu.app` — used for a large share of anime poster/cover art alongside AniList — is not in that list, so every image hosted there is silently blocked by the browser and falls back to a blank/gradient placeholder. Observed 9 distinct `media.kitsu.app` URLs blocked on `/about` alone (100+ repeated violation events in the console). This is almost certainly the root cause of several "blank purple/green gradient poster" bugs reported for Animation-genre titles (e.g. "Batman: Knightfall", "Avatar Aang: The Last Airbender").
**Evidence:** Console CSP violation messages naming `media.kitsu.app` URLs, repeated across every anime-carousel-bearing page tested.
**Suggested fix:** Add `https://media.kitsu.app` to the `img-src` directive. One-line fix, wide-reaching impact — this should be prioritized near the top.

---

### F-05 — Video player gets stuck in a broken state after switching sources, then exiting
**Severity:** High
**Area:** Video player / state management
**URL(s):** TV detail page (Breaking Bad)
**Repro:** Open an episode, switch the source dropdown at least once, then click "Exit player".
**Expected:** The player closes cleanly back to the detail page.
**Actual:** "Exit player" does not close the player. It instead shows a stuck placeholder: title renders as the raw TMDB id ("Series (1396)"), a spinner-locked "Loading Mars #1..." caption that has nothing to do with the title, and a stuck 0:00/0:00 progress bar. The Guest account dropdown is also left open on top of it. A second click on "Exit player" does nothing. Only a full page reload recovers the page.
**Evidence:** Reproduced directly; confirmed reproducible (not a one-off timing glitch).
**Suggested fix:** Likely a stale reference to the previously-selected source/now-playing item combined with the exit handler not actually unmounting the player component. Worth checking whether this correlates with the React hydration mismatch (F-10).

---

### F-06 — `/anime` (and other unmatched routes) fall through to the Sign In screen instead of loading or 404ing
**Severity:** High
**Area:** Routing / auth
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/anime`, and, for comparison, `https://cache-proxy.zainrana553.workers.dev/totally-fake-path`
**Repro:** As a logged-out guest, navigate directly to `/anime`.
**Expected:** The anime hub loads publicly, matching its sibling hubs `/movies` and `/tv-shows` (both fully public for guests), matching the site's own "no account needed to browse" messaging, and matching robots.txt / sitemap treatment (listed at priority 0.9, same tier as `/movies` and `/tv-shows`).
**Actual:** Direct navigation to `/anime` lands on the Sign In screen (full login form: OAuth buttons, email/password fields, "Continue as Guest" link, "Create account" link). Testing a route that definitely does not exist, `/totally-fake-path`, produces the *same* Sign In screen rather than a 404 — which points to the real mechanism being a broad "unmatched route" fallback rather than an anime-specific gate. In other words, `/anime` most likely isn't wired up as its own server-side route at all (it may only work as client-side navigation from a nav link/card), so a direct hit or refresh falls through the same catch-all that any nonexistent URL hits.
**Evidence:** Both URLs produce an identical Sign In interstitial; `/movies` and `/tv-shows` do not.
**Suggested fix:** Two separate things need fixing: (1) `/anime` should be a real, directly-loadable public route like its siblings; (2) independent of that, the catch-all for genuinely unmatched routes should be a styled 404 page, not a login wall — a login wall on a typo'd URL is a confusing dead end for a guest and likely hurts SEO if Googlebot hits it on any not-yet-indexed URL.

---

### F-07 — `/directors` claims "top 60 directors" but only renders 4; auto-generated copy has a typo
**Severity:** Medium-High
**Area:** Content / directory pages
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/directors`
**Repro:** Load `/directors`.
**Expected:** A directory living up to its own headline ("Discover the top 60 most popular film and television directors...").
**Actual:** Exactly 4 director cards render (Alfonso Cuarón, Lim Ka-hee, Christopher Nolan, John Frankenheimer) — no pagination, no "show more". The page's own dynamically-interpolated summary text reads "...the **4most** popular filmmakers currently trending..." — a literal missing-space typo, and it confirms the copy is correctly reading the true count (4) while the static headline above it still claims 60. This matches the `directors.xml` sitemap finding (F-21): the directors dataset is nearly empty.
**Evidence:** Direct page read; cross-referenced against sitemap.
**Suggested fix:** Either populate the directors dataset to match the "top 60" claim, or change the headline copy to reflect actual content; fix the "4most" → "4 most" spacing bug in the copy-generation template.

---

### F-08 — Date/year filtering bug: multiple views show titles with the wrong year
**Severity:** Medium-High
**Area:** Content filtering / date logic
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/release-calendar`, `https://cache-proxy.zainrana553.workers.dev/decade/1990s`
**Repro:** Load `/release-calendar` (an "upcoming releases, next ~9 months" view); separately load `/decade/1990s`.
**Expected:** Release Calendar shows only genuinely upcoming titles; the 1990s decade page shows only 1990s titles.
**Actual:** Release Calendar (framed as "upcoming · 9 months") includes titles dated Aug 1986, Dec 1993, Mar 1996, and Dec 1996 — all decades in the past, not upcoming. Separately, `/decade/1990s` — which otherwise correctly lists real 1990s titles (Shawshank Redemption, The Sopranos, Schindler's List, Pulp Fiction, etc.) — also includes "Demon Slayer: Kimetsu no Yaiba", which is a 2019 anime title (confirmed via its own detail URL: `/anime/demon-slayer-kimetsu-no-yaiba-2019-100038000`).
**Evidence:** Direct observation on both pages; the anime title's own detail page year cross-checked.
**Suggested fix:** This is the same shape of bug in two different views, which suggests a shared root cause — most likely a date/year field being read or compared incorrectly for at least some entries, and specifically implicating AniList/Kitsu-sourced (anime) entries, which appear to behave differently from TMDB-sourced entries elsewhere in the app too (see F-04). Worth checking whether decade/year/release-date logic uses a different field (e.g. "season year" vs. calendar air date) for anime vs. movies/TV, and auditing other date-based views (`/year/*`, `/coming-soon`, `/new-releases`) for the same issue.

---

### F-09 — Invalid CSP `frame-src` wildcard syntax is silently dropped
**Severity:** Medium
**Area:** Content Security Policy / video player
**URL(s):** Site-wide (fires in console on nearly every page load)
**Repro:** Load any page and check the console.
**Expected:** CSP `frame-src` allows the intended embed domains.
**Actual:** The `frame-src` directive includes `https://cf.*.site` and `https://*.vidsrc.*` — both invalid CSP syntax (a `*` cannot sit in the middle of a domain; CSP only supports a leading `*.` for subdomains). Browsers silently ignore malformed source expressions like these rather than erroring loudly, so these two intended allowances are not actually in effect. This likely explains inconsistent behavior across the `vidsrc.*`-family sources (VidSrc IO/PM/CC), which may be relying on an allowance that isn't actually applied.
**Evidence:** Console CSP text captured verbatim; repeats on effectively every page load.
**Suggested fix:** Replace with valid explicit entries, e.g. `https://*.vidsrc.io`, `https://*.vidsrc.pm`, `https://*.vidsrc.cc`, and whatever concrete host(s) `cf.*.site` was meant to represent.

---

### F-10 — React hydration mismatch (minified error #418) on nearly every route
**Severity:** Medium
**Area:** Frontend / SSR
**URL(s):** Site-wide
**Repro:** Load almost any page and check console.
**Expected:** Clean hydration, no console errors.
**Actual:** "Uncaught React error #418" (hydration failed: initial UI didn't match what the server rendered) fires on nearly every route tested. Doesn't visibly crash the page, but hydration mismatches like this are a common source of subtle state bugs (worth checking for a correlation with F-05, the stuck-player bug) and can hurt SEO/perceived performance.
**Evidence:** Console error, repeated across routes.
**Suggested fix:** Track down the component rendering different markup server-side vs. client-side on first paint (React DevTools in a real dev environment will name the component; this is not diagnosable further from black-box browser testing alone).

---

### F-11 — "Genres" and "More" nav dropdowns never open
**Severity:** Medium
**Area:** Primary navigation
**URL(s):** Homepage and site-wide (persistent header)
**Repro:** Click or hover the "Genres" or "More" items in the top nav, each of which shows a chevron indicating a dropdown.
**Expected:** A dropdown menu appears.
**Actual:** Nothing appears — confirmed via the accessibility tree that no new menu markup is added to the DOM after the click, on a clean page load, repeated attempts.
**Evidence:** Accessibility-tree diff before/after click showed no new elements.
**Suggested fix:** Likely a JS event-handler or CSS visibility bug specific to these two menu items (other nav items work). Given `/genres` itself is also broken (F-01), this dropdown may be effectively hiding that bug from most users today — worth fixing both together rather than one masking the other.

---

### F-12 — Search has no "no results" empty state on the Anime/People tabs
**Severity:** Medium
**Area:** Search
**URL(s):** Search modal, Anime tab and People tab
**Repro:** Open search, switch to the Anime tab, search a term with zero matches (e.g. "spider"); or switch to the People tab and search "naruto".
**Expected:** A "No results found" message or similar explicit empty state.
**Actual:** A blank area with no message — a user can't tell if the site is still loading, or if there's genuinely nothing to show.
**Evidence:** Direct observation, both tabs.
**Suggested fix:** Add an explicit empty-state message per tab (already present on some tabs, per session-1 testing — Shows tab correctly shows results for matching queries, the gap is specifically the zero-result case on Anime/People).

---

### F-13 — Low-reliability video sources fail completely silently
**Severity:** Medium
**Area:** Video player
**URL(s):** Any detail page, low-ranked sources in the dropdown (e.g. "VidSrc CC (T1) [31%]")
**Repro:** Select a low-reliability-percentage source from the dropdown.
**Expected:** Either it plays, or a clear "this source failed, try another" prompt appears.
**Actual:** Fully black player, no poster, no error message, no fallback suggestion — identical failure mode to F-03 (anime) but here on movie/TV sources too.
**Evidence:** Direct observation.
**Suggested fix:** Since sources are already ranked by a reliability percentage, auto-suggest (or auto-fall-back to) the next-best source when a player comes up empty, rather than leaving the user looking at a black box.

---

### F-14 — In-player ad overlay mimics a system/security prompt
**Severity:** Medium
**Area:** Video player / trust & safety
**URL(s):** Movie detail page (Moana), default "VidCore" source
**Repro:** Start playback on the default source.
**Expected:** No unrelated overlays inside the player.
**Actual:** A small overlay appears inside the player reading approximately "Connect to VPN Protection ... via Web App" with a green icon, styled to resemble a legitimate system/security notification. This is almost certainly injected by the embed provider rather than something Lumovia added deliberately, but it renders directly inside Lumovia's own player UI and could plausibly trick a user into clicking it.
**Evidence:** Direct observation during playback.
**Suggested fix:** Same remediation direction as F-02 — tier/vet embed sources, and/or sandbox the iframe more tightly if the provider's contract allows it.

---

### F-15 — `/api/health` exposes internal infrastructure details, unauthenticated
**Severity:** Medium
**Area:** Security / information disclosure
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/api/health`
**Repro:** Load the URL directly, no auth.
**Expected:** At most a bare `{"status":"ok"}` for anonymous callers.
**Actual:** Full JSON returned with no auth required: `{"status":"ok","timestamp":"...","uptime_ms":22,"checks":{"tmdb_credentials":{"ok":true,"detail":"Configured"},"tmdb_api":{"ok":true,"detail":"OK via Worker (HIT) in 22ms — 10000 results","latencyMs":22},"supabase":{"ok":true,"detail":"URL configured: koucyokdqncnywzzwmow.supabase.co"},"redis":{"ok":true,"detail":"URL configured: fast-firefly-163089.upstash.io"},"embed_providers":{"ok":true,"detail":"5/7 providers alive"}}}`. No credential *values* are leaked, but the exact Supabase project hostname and exact Upstash Redis hostname are both revealed — concrete, previously-unguessable targets for further probing (e.g. checking for Row-Level-Security gaps via PostgREST on the named Supabase host) — plus live operational detail (embed-provider uptime ratio) that a public/anonymous caller has no legitimate need for.
**Evidence:** Full response body captured verbatim above.
**Suggested fix:** Gate the detailed `checks` breakdown behind an internal-only auth header or IP allowlist; return only `{"status":"ok"}` (or a generic aggregate) to public/anonymous callers.

---

### F-16 — Video-source dropdown: displayed label desyncs from the actually-selected value
**Severity:** Medium
**Area:** Video player UI
**URL(s):** Reproduced independently on a TV episode player and an anime player
**Repro:** Use the source-select dropdown to pick a specific source.
**Expected:** The visible label matches the selected value.
**Actual:** The underlying `<select>` value is correct (confirmed via accessibility-tree/DOM inspection), but the separate visual label span sometimes shows a different, stale source name — e.g. after selecting "2Embed Anime" (value=2), the visible label instead read "VidSrc CC Anime (T1) [37%]", a different, lower-ranked option.
**Evidence:** Reproduced on two independent player instances (TV and anime), confirmed via DOM inspection after each `select` action, ruling out a one-off rendering glitch.
**Suggested fix:** The label span is likely reading from stale local state instead of the `<select>`'s current value on change — a systemic bug in the shared source-switcher component, not per-page.

---

### F-17 — Mood Quiz leaves a stuck near-opaque overlay after answering
**Severity:** Medium
**Area:** Homepage / modal UI
**URL(s):** Homepage, "Mood Quiz" entry point
**Repro:** Open "Mood Quiz" from the homepage, answer the first question ("What's your energy level?" → "Energetic").
**Expected:** The modal either advances to the next question or closes cleanly.
**Actual:** The modal closes, but the dark backdrop overlay stays at near-full opacity over the entire page. Page content is technically still there and interactable underneath, but effectively unreadable. Waiting several seconds does not clear it (ruled out as just a slow transition); only a full page reload does.
**Evidence:** Direct observation, reproduced.
**Suggested fix:** The backdrop element's dismiss handler is likely not firing on this particular modal-close path (vs. e.g. clicking an explicit close button, which presumably works).

---

### F-18 — Anime detail pages show no hero/backdrop image at all
**Severity:** Low-Medium
**Area:** Content / images
**URL(s):** `/anime/demon-slayer-kimetsu-no-yaiba-2019-100038000` and other anime detail pages
**Repro:** Load any anime detail page and wait.
**Expected:** A backdrop/hero image appears, even if delayed (as movie/TV detail pages do — see F-22).
**Actual:** No hero/backdrop image ever appears for anime titles — not delayed, simply absent. Consistent with the `media.kitsu.app` CSP gap (F-04) blocking the backdrop image outright rather than just delaying it, since anime backdrops are also Kitsu-hosted.
**Evidence:** Direct observation, contrasted against movie/TV detail pages in the same session.
**Suggested fix:** Same fix as F-04 — once `media.kitsu.app` is CSP-allowed, confirm this resolves on its own.

---

### F-19 — `news.xml` and `reviews.xml` sitemaps contain no individual articles/reviews
**Severity:** Low-Medium
**Area:** SEO / sitemaps
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/news.xml`, `.../reviews.xml`
**Repro:** Fetch each sub-sitemap directly.
**Expected:** Individual news articles / reviews listed, the way `blog.xml` (9+ articles) and `guides.xml` (8+ guides) both correctly do.
**Actual:** Each of `news.xml` and `reviews.xml` contains only the hub URL itself (`/news`, `/reviews`) — no individual content items indexed, even though the site clearly has (or plans to have) individual news/review content as sections.
**Evidence:** Direct sitemap inspection.
**Suggested fix:** Either these sections have no individual content yet (in which case this is expected and not a bug) or the sitemap generator for these two content types isn't picking up entries the way the blog/guides generators do — worth a quick check on the CMS/content side.

---

### F-20 — Duplicate brand suffix in `<title>` tag on `/actors` and `/directors`
**Severity:** Low
**Area:** SEO
**URL(s):** `/actors`, `/directors`
**Repro:** Inspect the `<title>` tag on either page.
**Expected:** One instance of the brand name.
**Actual:** Both end in "... | Lumovia | Lumovia" — the brand name appears twice. Likely a page-level title that already includes "| Lumovia" being wrapped by a layout template that appends "| Lumovia" again.
**Evidence:** Direct `<title>` inspection on both pages.
**Suggested fix:** Remove the brand suffix from one of the two layers (page-level title generation or the layout wrapper).

---

### F-21 — `directors.xml` sitemap has only 2 entries, both under the wrong path, one with a broken slug
**Severity:** Low
**Area:** SEO / sitemaps
**URL(s):** `https://cache-proxy.zainrana553.workers.dev/directors.xml`
**Repro:** Fetch the sitemap directly.
**Expected:** A director-specific sitemap with `/director/...` paths, roughly matching the "top 60" claim on `/directors` (F-07).
**Actual:** Only 2 URLs total, and both use the `/actor/` path, not `/director/`: `/actor/alfonso-cuar-n-11218` and `/actor/lim-ka-hee-2379419`. The first also has a broken slug — the accented "ó" in "Cuarón" was dropped/replaced with a bare hyphen ("cuar-n") instead of being transliterated (e.g. to "cuaron").
**Evidence:** Direct sitemap inspection.
**Suggested fix:** Fix the accented-character slug generator (this will affect any name with non-ASCII characters, not just this one director); decide whether directors should have their own `/director/` path or intentionally redirect to `/actor/` (and if so, the sitemap should reflect that consistently).

---

### F-22 — Hero/backdrop images on movie/TV detail pages take several seconds to fade in
**Severity:** Low
**Area:** Performance / images
**URL(s):** Movie/TV detail pages generally
**Repro:** Load any movie or TV detail page and watch the top of the page.
**Expected:** The backdrop appears promptly, ideally via the `<link rel=preload>` hint already present for it.
**Actual:** The page renders with a completely blank dark hero area for several seconds before the backdrop fades in. Paired with a separate, related console warning: dozens of repeated "resource preloaded but not used" warnings for the same hero image URL (`image.tmdb.org/.../c6BPbkO5Npt1OdwttAxCFo06wtH.jpg`) on the homepage — meaning the image is being preloaded but the browser doesn't end up using that preloaded fetch for the image that actually renders, wasting the bandwidth/priority benefit the preload was meant to provide.
**Evidence:** Direct observation + console warning text.
**Suggested fix:** Check that the preloaded URL exactly matches (including query params/CDN transform params) the URL actually used in the rendered `<img>`/CSS background.

---

### F-23 — Poster image fails to render for at least one specific title ("Batman: Knightfall Part 1")
**Severity:** Low
**Area:** Content / images
**URL(s):** Movies page, Browse page — "Batman: Knightfall Part 1: Knightfall"
**Repro:** Locate this title on either page.
**Expected:** Poster image renders.
**Actual:** Flat purple gradient placeholder, no image — reproduced on both the Movies page and Browse page. Other Animation-genre titles (Avatar Aang, Swapped) loaded fine on repeat visits, so this looks specific to this title's image data/source rather than a general network issue (though it may share a root cause with F-04 if this title is also Kitsu-sourced — not confirmed either way).
**Evidence:** Direct observation, reproduced across two pages.
**Suggested fix:** Check this title's stored `poster_path`/image source specifically.

---

### F-24 — Leftover "Lumina" branding in multiple user-facing/internal strings
**Severity:** Low
**Area:** Branding / cosmetic
**URL(s):** Sign-in form email placeholder; service worker source
**Repro:** Open the inline sign-in modal (e.g. via "+ My List"); separately inspect `sw.js`.
**Expected:** Consistent "Lumovia" branding throughout.
**Actual:** Three places show the old/wrong brand name "Lumina" instead of "Lumovia": (1) the inline sign-in modal's email placeholder reads `you@lumina.stream`; (2) the standalone `/anime`-adjacent sign-in *screen's* email placeholder instead reads the generic `you@example.com` — i.e. two different sign-in entry points use two different, inconsistent placeholder values, one of them wrong-branded; (3) the service worker's cache name constant is `CACHE_NAME = 'lumina-v5'`. None of these are user-blocking, but together they indicate the product was renamed from "Lumina" to "Lumovia" without a full find-and-replace pass.
**Evidence:** Direct inspection of both sign-in entry points and `sw.js` source.
**Suggested fix:** Grep the codebase for "lumina" (case-insensitive) and replace remaining instances; standardize on one placeholder value across both sign-in entry points.
