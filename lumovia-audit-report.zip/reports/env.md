# Environment & Methodology

**Site under test:** Lumovia — `https://cache-proxy.zainrana553.workers.dev`
**Audit dates:** 2026-09-10 (two sessions, same day)
**Auditor:** Claude, black-box only — no source, server, or database access; everything below comes from observable browser behavior (DOM, console, network panel, rendered content).

## Tooling used

- Claude's built-in browser (Chromium-based), driven via automation tools: navigation, screenshot/vision, DOM/accessibility-tree inspection, console log capture, network request/status capture, viewport resize (desktop / 375×812 mobile-preset / tablet), form input, keyboard/click simulation.
- No Lighthouse, no axe-core, no curl/HTTP-header-inspection tooling was available in this environment. Where the spec asked for Lighthouse scores, raw response headers (HSTS, X-Content-Type-Options, etc.), or an axe-core scan, this is called out explicitly as **N/A (tool not available)** rather than guessed at — see `checklist.md` and `security.md`.

## Hard constraints (self-imposed, disclosed to the user before starting)

1. **No login, no account creation, no passwords typed anywhere** — this is a fixed rule regardless of the audit brief's authorization language. Every checklist item that requires an authenticated session (profile CRUD, watchlist/ratings/collections persistence, comments, notifications, stats/activity/year-in-review, Watch Party) is marked `N/A (requires login — not attempted)`.
2. **No screenshot files could be saved to disk** — the browser tool used renders/analyzes screenshots in-session but cannot export them as image files. Every visual finding below is instead described in enough concrete detail (exact text, colors, layout, reproduction steps) to be independently reproduced and confirmed. No `screenshots/` folder is included in this bundle.
3. **No exhaustive click-every-card testing.** The catalog is "10K+ titles" scale. Interaction *patterns* (card → detail, source dropdown, carousel arrows, load-more, etc.) were fully tested on representative pages; a broad status/console sweep was run across every enumerable *route type* (every hub, every static/legal page, every distinct dynamic-route shape) so nothing was silently skipped at the route-type level, but not every one of the thousands of individual title pages was opened.
4. **Two-tab Watch Party sync, multi-tab host/guest testing, and anything needing a second real account or email delivery** are marked `N/A (needs a 2nd real account / email — not attempted)` per the rules of engagement.

## Scope actually covered

- Full sitemap-index discovery (`sitemap.xml` → 13 sub-sitemaps) and content audit of each sub-sitemap.
- `robots.txt`, `manifest.json`, `sw.js` (service worker) full read-through and analysis.
- All 28 `pages.xml` hub/static routes visited; all 6 genre portals; representative movie, TV, and anime detail + player pages; several intentionally-invalid routes (`/details/99999999`, `/person/99999999`, `/totally-fake-path`) to probe error handling.
- Full interactive sweep on homepage, Movies, TV Shows, Browse, Anime hub, Genres/More nav, Mood Quiz, search (3 tabs), video player (multiple sources on movie/TV/anime).
- `/api/health` and `/api/search` endpoints exercised directly; remaining `/api/*` endpoints (browse, tmdb, embed, player/resume, comments, watchlist, notifications, watch-party) were **not** exercised — most require an authenticated session and were out of scope under constraint #1; this is called out per-endpoint in `security.md`.
- CSP header text captured verbatim from console violation messages (two separate directives found faulty: `frame-src` and `img-src`).

## What this bundle does NOT contain

- A `screenshots/` folder (constraint #2 above) — visual bugs are described in `findings.md` instead.
- A Lighthouse/PageSpeed report or axe-core violation list (tooling not available) — marked N/A in `checklist.md`.
- Verified response-header values (HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy) — the browser tool used does not expose raw response headers, only status codes and console-visible policy violations. Marked N/A in `security.md`.
- Results for authenticated-only flows (constraint #1).
