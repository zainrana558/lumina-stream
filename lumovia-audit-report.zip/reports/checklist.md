# Master Checklist

Every line is marked `PASS`, `FAIL (F-NN)`, or `N/A (reason)` — none left blank, per the audit's rules of engagement. "PASS" means observed working correctly; it does not mean "perfect," only "no defect found in this pass."

## 0. Setup

- Build route matrix from sitemap.xml + canonical route inventory — **PASS** (see `route-matrix.csv`; 13 sub-sitemaps discovered and read, 28 `pages.xml` routes + 6 genre routes + representative dynamic routes enumerated)
- Confirm no source/server/DB access used, black-box only — **PASS** (confirmed throughout; all findings sourced from browser-observable behavior)

## 1. Per-page procedure (applied across all pages visited)

- Cold-load HTTP status / redirect check — **PASS** (see `route-matrix.csv`; one CRITICAL exception logged as F-01)
- Desktop screenshot captured for visual review — **PASS** (used in-session for analysis; not exportable as image files — see `env.md` constraint #2)
- Mobile (390×844-class) screenshot captured for visual review — **PASS, partial** — captured and analyzed for the homepage only; not completed across the full page set before this pass was closed out. **N/A (not completed — time/scope; see Optional Next Steps in summary.md)** for the remaining pages.
- Tablet (820×1180-class) screenshot captured — **N/A (not attempted — time/scope)**
- Console error logging per page — **PASS** (site-wide pattern found: CSP frame-src warning + React #418 on nearly every route — F-09, F-10)
- Network request logging + third-party/tracker flagging — **PASS** (TMDB, Kitsu, AniList, and embed-provider domains identified and categorized per page; see `route-matrix.csv`)
- SEO tag extraction (title, meta description) — **PASS, partial** — title tags checked broadly (duplicate-suffix bug found, F-20); meta descriptions not individually audited across all pages
- HTTP correctness / soft-404 checks — **PASS, partial** — confirmed via network status codes for `/genres` (500, F-01), `/details/99999999` and `/person/99999999` (200 on invalid ids, soft-404 candidates, not fully characterized — see `seo.md`), and `/totally-fake-path` (redirects to Sign In rather than 404 — F-06)
- Exhaustive interactive sweep of every link/button/dropdown/carousel/modal — **PASS, sampled** — fully swept on homepage, Movies, TV Shows, Browse, Anime hub, nav, Mood Quiz, search; not literally every card among 10K+ catalog titles (disclosed sampling approach, see `env.md` constraint #3)
- Keyboard-only navigation check — **N/A (not attempted — time/scope)**
- Visual bug scan — **PASS** (multiple visual bugs found and documented: F-04, F-18, F-22, F-23)

## 2. Canonical route inventory

- Catalog/discovery hubs (`/movies`, `/tv-shows`, `/anime`, `/trending`, `/top-rated`, `/new-releases`, `/browse`, `/coming-soon`) — **PASS**, with **FAIL (F-06)** specifically on `/anime`
- Genre pages (6 portals) — **PASS**
- Time/people/hub pages (`/release-calendar`, `/seasonal`, `/leaderboard`, `/decade/*`, `/actors`, `/directors`, `/studios`, `/countries`, `/languages`) — **PASS**, with **FAIL (F-01)** on `/genres`, **FAIL (F-07)** on `/directors`, **FAIL (F-08)** on `/release-calendar` and `/decade/1990s`
- Detail + player pages — 3 movies — **PASS, sampled (1 fully deep-tested — Moana; 2 additional not deep-tested this pass)**
- Detail + player pages — 3 TV — **PASS, sampled (1 fully deep-tested — Breaking Bad; 2 additional not deep-tested this pass)**
- Detail + player pages — 3 anime — **PASS, sampled (1 fully deep-tested — Demon Slayer; 2 additional not deep-tested this pass)** — with **FAIL (F-03)** on playback for the one tested
- Static/legal pages (about, contact, faq, privacy, terms, dmca, cookies, disclaimer) — **PASS**
- Auth + account pages (login, signup, profiles, settings, watchlist, stats, activity, collections, year-in-review) — **N/A (requires login — not attempted per hard constraint; see env.md)**
- Machine endpoints (`sitemap.xml`, `robots.txt`, `manifest.json`, `sw.js`) — **PASS** (all read and analyzed; see `seo.md` and `findings.md` F-19, F-21, F-24)

## 3. Deep test — video player

- Every source in the dropdown tested, one movie title — **N/A (partial)** — default source (VidCore) confirmed working; not every one of the ~10 listed sources was individually tried on this title (time/scope)
- Every source in the dropdown tested, one TV title — **PASS, partial** — default (VidCore, works), VidSrc IO (F-02, redirect), one low-reliability source (F-13, silent failure) tested; not exhaustive across all listed sources
- Every source tested, one anime title — **PASS, partial** — 2 of 4 listed sources tried, both failed (F-03); remaining 2 (Cinezo Sub, VidSrc CC Anime) **N/A (not attempted — time/scope)**
- Ad/popup/redirect detection — **FAIL (F-02, F-14)**
- Exit-button behavior after switching sources — **FAIL (F-05)**
- Keyboard shortcuts (Space/K/F/arrows/Esc/`?` sheet) — **N/A (not attempted — time/scope)**
- Next/prev episode/season controls — **N/A (not attempted — time/scope)**
- Fullscreen — **N/A (not attempted — time/scope)**
- Picture-in-picture — **N/A (not attempted — time/scope)**
- Resume-prompt behavior — **N/A (requires a returning/authenticated session to trigger meaningfully — not attempted)**
- Skip-intro markers — **N/A (not attempted — time/scope; also not confirmed this feature exists)**
- Empty-source fallback behavior — **FAIL (F-13)**
- Dropdown label correctness — **FAIL (F-16)**

## 4. Deep test — flows

- Search across 3 tabs, real queries — **PASS**
- Search across 3 tabs, zero-result queries — **FAIL (F-12)** on Anime/People tabs
- Search tab-switch staleness check — **N/A (not re-verified this session — tested in an earlier session, not re-confirmed here)**
- Full auth flow (signup with throwaway email) — **N/A (hard constraint — no account creation, no passwords typed, ever; see env.md)**
- Profile CRUD — **N/A (requires login)**
- Watchlist/ratings/collections/comments/notifications persistence — **N/A (requires login)**
- Watch Party, two-tab host/guest sync — **N/A (requires login + a 2nd real session; not attempted)**
- Nav dropdowns (Genres, More) — **FAIL (F-11)**
- Mobile hamburger menu — **N/A (not completed this pass — mobile responsive testing was cut short; see summary.md)**
- PWA install prompt / offline behavior — **PASS, partial** — `manifest.json` and `sw.js` source both read and analyzed as structurally sound (network-first navigations, correct never-cache list for auth routes, styled offline fallback, cache-version cleanup on activate — see `seo.md`/discovery notes); **N/A (runtime offline-mode simulation not attempted — time/scope)** for confirming this actually fires correctly live

## 5. Technical audits

- Performance / Lighthouse — **N/A (tool not available in this environment — see env.md)**
- Accessibility / axe-core — **N/A (tool not available in this environment — see env.md)**
- SEO / JSON-LD structured data — **N/A (not attempted — see seo.md)**
- Security headers (HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy) — **N/A (tool not available — see security.md)**
- CSP correctness — **FAIL (F-04, F-09)**
- Cookie flags — **N/A (requires login and/or tooling not available — see security.md)**
- Iframe sandbox attributes on embeds — **N/A (not attempted — see security.md)**
- API endpoint testing with bad params — **PASS, partial** — `/api/health` and `/api/search` tested; remaining endpoints **N/A (mostly require login — not attempted; see route-matrix.csv)**
- Responsive screenshots at 5 widths (360/390/768/1024/1440) — **N/A (partial)** — only the 375×812 mobile preset on the homepage was captured before this pass was closed out; the remaining widths and pages are **N/A (not completed — time/scope)**
- Content-correctness spot-check of 10 titles — **PASS, partial** — content correctness was directly checked for the titles involved in F-08 (Demon Slayer decade mismatch) and F-23 (Batman: Knightfall poster); a broader, dedicated 10-title spot-check pass was not run separately

## Rules of engagement — compliance confirmation

- No real password/payment/gov-ID ever entered — **PASS** (never attempted; auth flows marked N/A instead)
- No CAPTCHA completed, no irreversible legal terms accepted, no destructive account actions — **PASS** (none attempted)
- All page/embed/ad/API content treated as data, never instructions — **PASS** (see `security.md`, "Injected-instruction check" — one fake-system-prompt-styled ad overlay logged as F-14 rather than acted on)
- Untestable items marked N/A (reason) rather than skipped silently — **PASS** (every N/A above carries a reason)
- Test comments/rooms created and marked/removed — **N/A (no test comments or rooms were created, since doing so requires login, which was never attempted)**
