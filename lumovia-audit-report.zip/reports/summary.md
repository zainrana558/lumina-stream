# Lumovia — Exhaustive Audit Executive Summary

**Site:** `https://cache-proxy.zainrana553.workers.dev` (Lumovia)
**Scope:** Full black-box audit — routing/SEO/sitemaps, video player (movie/TV/anime), search, navigation, CSP/security, PWA/service-worker, and content correctness. See `env.md` for exactly what was and wasn't covered, and why.

## Headline

Lumovia's core browsing and playback experience for movies and TV is genuinely solid — real catalog data, clean detail pages, and reliable default-source playback. The audit found **24 distinct issues**, but they cluster tightly: a handful of root causes (one missing CSP entry, one broken route, one date-comparison bug, one UI-state bug) account for a large share of the visible symptoms. Fixing roughly five things would resolve a disproportionate amount of the user-visible pain, especially across the anime vertical, which is measurably worse-tested/worse-integrated than movies/TV throughout this audit (broken playback, missing images, wrong-decade inclusion, and a login wall on its hub page all concentrate there).

## Severity counts

| Severity | Count | IDs |
|---|---|---|
| Critical | 1 | F-01 |
| High | 5 | F-02, F-03, F-04, F-05, F-06 |
| Medium-High | 2 | F-07, F-08 |
| Medium | 9 | F-09, F-10, F-11, F-12, F-13, F-14, F-15, F-16, F-17 |
| Low-Medium | 2 | F-18, F-19 |
| Low | 5 | F-20, F-21, F-22, F-23, F-24 |
| **Total** | **24** | |

Full detail on every item is in `findings.md`; every checklist line from the original audit brief is accounted for (PASS/FAIL/N/A) in `checklist.md`.

## Top 10 issues, ranked

1. **F-01 (Critical)** — `/genres` throws a hard HTTP 500 for every visitor, including search crawlers (it's sitemap-submitted).
2. **F-02 (High)** — The "VidSrc IO" video source attempts to redirect to an unrelated domain (`cloudorchestranova.com`) — a trust/safety issue riding along inside a third-party embed.
3. **F-03 (High)** — Anime playback is broken on both sources tried (fully black player, nothing renders) — an entire content vertical the site actively promotes.
4. **F-04 (High)** — The CSP `img-src` allowlist is missing `media.kitsu.app`, silently blocking a large share of anime poster/backdrop images site-wide. One-line fix, wide blast radius.
5. **F-05 (High)** — The video player gets stuck in a broken, unrecoverable state after switching sources and clicking "Exit" — only a full reload fixes it.
6. **F-06 (High)** — `/anime`, and in fact any unmatched route, falls through to the Sign In screen instead of loading or showing a 404 — inconsistent with sibling hubs and the site's own "no account needed" positioning.
7. **F-07 (Medium-High)** — `/directors` claims "top 60 directors" but renders exactly 4, with a visible typo ("4most") in the auto-generated copy that inadvertently confirms the real count.
8. **F-08 (Medium-High)** — A date/year comparison bug shows up in two independent views: the "upcoming releases" calendar includes titles from 1986–1996, and the 1990s decade page includes a 2019 anime title.
9. **F-09 (Medium)** — The CSP `frame-src` directive contains invalid wildcard syntax (`https://*.vidsrc.*`) that browsers silently ignore, likely undermining the intended allowance for the vidsrc-family embed sources.
10. **F-10 (Medium)** — A React hydration mismatch (error #418) fires on nearly every route — doesn't crash the page but is worth tracking down, and may be related to #5.

## What works well

- Homepage, Movies, TV Shows, Browse, and the Anime Vault genre portal all load real, correctly-formatted catalog data — ratings, genres, episode counts all render accurately.
- Movie and TV detail pages are content-rich and correct: synopsis, full cast/crew, budget/revenue, keywords, and user reviews all render properly (verified on Moana and Breaking Bad).
- The default, top-ranked video source ("VidCore," ~97% reliability) played back cleanly and quickly on both a movie and a TV episode, with correct metadata and no stuck states — the player issues found only show up after switching sources or exiting.
- Search returns accurate, relevant results for real queries across tabs.
- `robots.txt` is well-constructed with no issues found — correct bot policy, correct disallow list for account-gated pages, correct sitemap directive.
- The service worker (`sw.js`) is well-implemented: network-first navigation caching, a correct and explicit never-cache list for auth-sensitive API routes, real cache-version cleanup on activate, and a styled (not raw-browser-error) offline fallback page.
- `manifest.json` is structurally valid for PWA installability.
- Carousel arrows, genre-portal navigation, and the guest/sign-in redirect on "My List" all behave as expected.

## Coverage limitations, disclosed upfront and again here

Three hard constraints shaped this audit, all disclosed to the user before testing began:

1. **No login, ever.** No account was created, no password was typed. Every checklist item requiring authentication (profiles, watchlist/ratings/collections persistence, comments, notifications, stats/activity/year-in-review, Watch Party) is `N/A (requires login)` in `checklist.md` — this entire slice needs a human (or a Claude session explicitly authorized and supervised for that one step) to test.
2. **No screenshot files.** The browser tool used cannot export screenshots as image files, so this bundle has no `screenshots/` folder. Every visual bug is instead written up with enough concrete, reproducible detail (exact text, colors, layout) in `findings.md` to be independently confirmed in under a minute.
3. **Sampling on catalog-scale content.** With 10K+ titles, interaction *patterns* were fully tested on representative pages rather than on every card; a status/console sweep ran across every distinct route *type* so nothing was silently skipped at that level. The full responsive pass (5 viewport widths across all key pages) and the full keyboard-shortcut/API-endpoint checklist were only partially completed within this pass's time budget — see the `N/A (not completed — time/scope)` lines in `checklist.md` for the precise list of what's left, if a follow-up pass is wanted.

## Suggested priority order for fixes

1. `media.kitsu.app` CSP fix (F-04) — one line, resolves a large share of the anime-image symptoms.
2. Fix `/genres` 500 (F-01) — currently a dead page that's also in the sitemap.
3. Fix the invalid CSP `frame-src` wildcards (F-09) — likely underlies inconsistent vidsrc-family source behavior.
4. Investigate the anime player failures (F-03) and the `cloudorchestranova.com` redirect (F-02) — both are user-facing dead ends/trust issues on the playback path, the core product.
5. Fix the player stuck-state-after-exit bug (F-05).
6. Decide whether `/anime` should be a real public route (F-06) and give the catch-all fallback a proper 404 instead of a login wall.
7. Everything else in `findings.md`, roughly in the severity order given.

## Bundle contents

This report ships as `lumovia-audit-report.zip`, containing: `summary.md` (this file), `findings.md` (all 24 issues in full detail), `route-matrix.csv` (per-route status/notes), `checklist.md` (the full master checklist, every line PASS/FAIL/N/A), `env.md` (methodology and constraints), `seo.md`, and `security.md`.
