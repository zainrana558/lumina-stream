# SEO Audit

## Sitemap structure

`/sitemap.xml` is a valid sitemap **index** pointing to 13 well-formed sub-sitemaps: `pages.xml`, `movies.xml`, `tvshows.xml`, `anime.xml`, `genres.xml`, `actors.xml`, `directors.xml`, `news.xml`, `reviews.xml`, `blog.xml`, `images.xml`, `videos.xml`, `guides.xml`. All sub-sitemaps returned valid XML (correct `urlset`/`sitemapindex` namespace) wherever checked.

| Sub-sitemap | Content | Verdict |
|---|---|---|
| `pages.xml` | 28 hub/static URLs (full list in `env.md`/`route-matrix.csv`) | PASS |
| `genres.xml` | 6 URLs, matches the 6 genre-portal cards | PASS |
| `actors.xml` | Hundreds of real `/actor/<slug>-<id>` entries | PASS |
| `directors.xml` | Only 2 entries, both under `/actor/` not `/director/`, one with a broken accented-character slug | **FAIL — see F-21** |
| `news.xml` | Only the `/news` hub itself, no individual articles | **FAIL — see F-19** |
| `reviews.xml` | Only the `/reviews` hub itself, no individual reviews | **FAIL — see F-19** |
| `blog.xml` | 9+ real article slugs, plausible `lastmod` dates (Jan–Feb 2026) | PASS |
| `guides.xml` | 8+ real guide slugs | PASS |
| `movies.xml` | Catalog-scale (thousands), sampled only | PASS (sampled) |
| `tvshows.xml`, `anime.xml`, `images.xml`, `videos.xml` | Not enumerated in full — assumed to mirror `movies.xml` at catalog scale | Not fully verified — sampled via detail pages only |

Note: `/decade/*`, `/year/*`, `/person/*` and all account-gated routes are intentionally absent from the XML sitemaps, which is correct (they're either dynamic filter views or should stay unindexed).

## robots.txt — PASS, no issues

- Explicitly disallows known SEO-scraper and AI-training bots (AhrefsBot, SemrushBot, MJ12bot, DotBot, BLEXBot, PetalBot, YandexBot, Baiduspider, Bytespider, GPTBot, ClaudeBot, anthropic-ai, CCBot, DataForSeoBot) — a deliberate policy choice, not a bug.
- The default `User-Agent: *` allow-list matches the canonical route inventory well, and additionally confirms routes not present in any XML sitemap really do exist as real paths: `/details/`, `/person/`, `/country/`, `/language/`, `/studio/`, `/decade/`, `/year/`.
- Correctly disallows all account-gated paths for */*: `/api/`, `/auth/`, `/embed/`, `/stats`, `/watchlist`, `/profiles`, `/select-profile`, `/login`, `/signup`, `/settings`, `/collections`, `/activity`, `/year-in-review`.
- `Crawl-delay: 10` set; `Sitemap:` directive present and points to the correct URL.

## Title tags

- Duplicate brand suffix on `/actors` and `/directors`: `"... | Lumovia | Lumovia"` — see **F-20**. Not confirmed on other page types during this pass (worth a broader spot-check).
- Titles elsewhere (homepage, movie/TV detail pages, hub pages) render sensibly and were not found to have this issue.

## JSON-LD / structured data

**Not checked this pass.** No JSON-LD extraction/validation tool was available in this environment (no `curl`/DOM-source-diffing pass was run specifically for `<script type="application/ld+json">` blocks). Marked **N/A (not attempted — see env.md)** in the checklist. If this matters for your SEO roadmap, a follow-up pass specifically diffing each template's structured data against schema.org's Movie/TVSeries/Review types would be the next step.

## Soft-404 candidates

`/details/99999999` and `/person/99999999` (nonexistent numeric ids) both return HTTP 200 rather than a 404 — confirmed via network status code. This is the textbook "soft 404" pattern the audit spec calls out. What content actually renders at those ids (a proper "not found" message vs. a broken/empty template) was **not** re-confirmed during this compilation pass — flagged for a quick follow-up rather than asserted definitively either way.

Separately, and more clearly a bug: a genuinely unmatched route (`/totally-fake-path`) falls through to the **Sign In** screen rather than any 404 at all — see **F-06**. This is arguably worse for SEO than a soft-404, since it means any bad/typo'd/old URL a crawler encounters presents as a login wall.
