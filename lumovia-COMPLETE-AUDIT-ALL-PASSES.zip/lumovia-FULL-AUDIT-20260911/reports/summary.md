# Executive Summary – Lumovia Black-Box Audit

**Target:** https://cache-proxy.zainrana553.workers.dev  
**Date:** 2026-09-11  
**Method:** Pure black-box (browser + network + headers + public files only)

**Overall verdict:**  
Lumovia is a polished, modern Next.js streaming aggregator with a strong visual design and broad content catalog drawn from TMDB/AniList. Core discovery pages load, auth surfaces exist, and the player attempts to connect to third-party sources. However, several high-impact issues exist: widespread soft-404s (HTTP 200 for invalid IDs), missing posters on catalog grids, extremely permissive CSP that allows aggressive ad/player domains, and player reliability dependent on external providers that often show loading states without clear failure messaging. Soft-404s and missing images are the most visible user-facing problems; the CSP + ad surface is the primary security/trust concern.

**Finding counts (approx from this session):**
| Severity  | Count |
|-----------|-------|
| Critical  | 1     |
| High      | 4     |
| Medium    | 6     |
| Low       | 5     |
| Info      | 4     |

**Top 10 issues (ranked):**
1. Soft-404s – invalid /details/, /movie/, /person/, /year/, /decade/, /genre/ IDs return HTTP 200 instead of 404 (Critical for SEO + UX)
2. Extremely permissive CSP + large ad/player domain allowlist (High – malware/ad risk)
3. Broken / missing posters on Movies, Browse, TV grids (High – visual quality)
4. Player frequently stuck in “Finding best provider / Connecting to Mercury…” with no clear empty-source message (High)
5. Catalog size claims (“10K titles”) vs observed section sizes (~100–120) (Medium)
6. Zero ratings displayed on multiple titles (Medium)
7. Account pages redirect (307) when logged out – good, but full auth/Watch Party flows not fully exercised without real mailbox (Medium)
8. No X-Frame-Options / tight frame-ancestors observed (Medium)
9. Potential hydration / large client JS surface (typical Next.js) – not confirmed as errors in this pass (Low)
10. robots.txt blocks many SEO bots but allows main content (Info)

**What works well:**
- Clean 404 page for unknown paths
- Good baseline security headers (HSTS preload, nosniff, XSS protection, Referrer-Policy, Permissions-Policy)
- Manifest.json valid for PWA
- Modern dark UI, consistent branding “Lumovia”
- APIs return clean JSON 200s with sensible shapes
- Login/signup UI polished; Continue-as-Guest option present
- Genre portals and discovery sections render

**Coverage note:** All routes listed in pages.xml (29) + additional canonical routes from the inventory were status-checked. Representative detail pages (movie, TV) and player flow were exercised. Full enumeration of ~700+ individual title URLs from movies/tv/anime sitemaps was sampled rather than exhaustively visited due to scale; patterns (missing posters, player behaviour) are consistent across samples. Full multi-tab Watch Party, email-confirmed signup, and axe-core injection were limited by tooling/session constraints and marked N/A where appropriate.

---

## Additional pass (Genre + Login + Settings)
All 6 genre portals (/genre/anime, cartoon, horror, romance, mystery, fantasy) audited and screenshot.
Login page fully screenshot (desktop + mobile).
/settings correctly redirects to login when unauthenticated.
No new Critical issues found in this pass. Genre pages show better poster coverage than the main Movies grid.
