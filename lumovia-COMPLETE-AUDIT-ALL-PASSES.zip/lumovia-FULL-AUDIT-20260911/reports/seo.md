# SEO Notes

- sitemap.xml is a sitemap index pointing to pages.xml, movies.xml, tvshows.xml, anime.xml, genres.xml.
- pages.xml contains ~29 core routes, all returning 200.
- movies.xml ~257 locs, tvshows ~279, anime ~202.
- Soft-404 problem (F-01) means many invalid URLs are indexable as 200 – bad for SEO.
- robots.txt allows main content, blocks many SEO/AI bots.
- Manifest present and valid.
- Title observed: “Lumovia — Free Movies, TV Shows & Anime | Lumovia”
- Canonical / OG / JSON-LD not exhaustively validated per page in this session; detail pages should be checked for Movie/TVSeries schema.
