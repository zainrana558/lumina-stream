# Security Notes

## Headers (homepage)
- strict-transport-security: max-age=31536000; includeSubDomains; preload  ✓
- x-content-type-options: nosniff  ✓
- x-xss-protection: 1; mode=block  ✓
- referrer-policy: strict-origin-when-cross-origin  ✓
- permissions-policy: camera=(), microphone=(), geolocation=()  ✓
- content-security-policy: present but permissive (see F-02)
- No explicit X-Frame-Options in the captured header set; frame-src in CSP is broad.

## Cookies
Not deeply inspected in logged-in state (auth limited). Expect Secure + HttpOnly + SameSite on session cookies if Supabase is used.

## Embeds
Player relies on third-party iframes (vidsrc*, vidcore, etc.). CSP allows them. No sandbox attribute observation recorded on the iframes themselves in this pass. Clicking Play can lead to provider connection attempts; popunder risk should be monitored (common on such sites).

## Secrets
No obvious API keys or internal tokens observed in public HTML/JS/network in this session.

## Mixed content
None observed (all https).
