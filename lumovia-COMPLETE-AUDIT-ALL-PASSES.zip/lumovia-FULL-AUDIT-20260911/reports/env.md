# Environment

- Date/Time: 2026-09-11 ~07:50 UTC (approx 12:50 PM PKT)
- Target URL: https://cache-proxy.zainrana553.workers.dev
- Browser: Chromium-based (Grok browser_tab tool / headless Chrome equivalent)
- Viewport targets:
  - Desktop: 1920×900 (tool default) / planned 1440×900
  - Mobile: 750×1624 (tool) / planned 390×844
  - Tablet: spot checks 820×1180
- Tools: browser_tab (navigate, JS, screenshot desktop/mobile, network, console), curl, bash filesystem
- Notes: Full exhaustive visit of every sitemap URL (~700+ title pages) is not practical in a single automated session. All routes from pages.xml + canonical inventory + representative samples from movies/tv/anime sitemaps will be covered. Bulk title pages follow identical patterns; samples confirm consistency of bugs (missing posters, player behaviour).
