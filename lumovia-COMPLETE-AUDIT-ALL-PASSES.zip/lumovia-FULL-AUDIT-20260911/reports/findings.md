# Findings (most severe first)

### F-01 — Soft-404s on invalid resource IDs
Severity: Critical  
Area: SEO / routing / content  
URL(s): /details/99999999?mt=tv, /details/2?mt=movie, /year/99, /decade/9999, /person/99999999, /genre/notarealgenre, /movie/nonexistent-999999  
Repro:  
1. Request any of the above URLs.  
2. Observe HTTP status.  
Expected: HTTP 404 + 404 page.  
Actual: HTTP 200 for all except pure unknown paths like /totally-fake-path (which correctly returns 404).  
Evidence: curl status checks; browser shows content or empty state under 200.  
Suggested fix: Return real 404 status for non-existent IDs; use proper not-found handling in Next.js.

### F-02 — Extremely permissive Content-Security-Policy
Severity: High  
Area: security  
URL(s): all HTML pages  
Repro: Inspect response headers.  
Expected: Tight CSP, minimal unsafe-inline, restricted frame-src/connect-src.  
Actual: script-src allows 'unsafe-inline' + many ad networks (propellerads, popads, highperformancedformats, intelligenceadx) and video domains (vidsrc*, vidcore.org, cinezo.live, etc.). frame-src and connect-src are broad.  
Evidence: headers-home.txt / curl -I.  
Suggested fix: Tighten allowlists; prefer nonces/hashes over unsafe-inline; sandbox embeds more aggressively.

### F-03 — Missing / broken posters on catalog grids
Severity: High  
Area: visual / content  
URL(s): /movies, /browse, /tv-shows (and likely others)  
Repro: Load the page; observe black/empty cards instead of posters.  
Expected: Every title has a poster or a graceful fallback image.  
Actual: Multiple cards render solid black with no image.  
Evidence: screenshots of /movies, /browse.  
Suggested fix: Add onerror fallback or placeholder; ensure TMDB paths are valid.

### F-04 — Player often fails to resolve a working source
Severity: High  
Area: player  
URL(s): movie detail pages (e.g. /movie/moana-2026-1108427)  
Repro: Click Play Now → observe “Finding best provider…” then “Connecting to Mercury #5…”; may never play or show black.  
Expected: Video starts or clear “No sources available / try another” message + auto-failover.  
Actual: Prolonged loading states; third-party dependency.  
Evidence: player screenshots.  
Suggested fix: Better empty-source UX, timeout + message, auto-advance.

### F-05 — Catalog size mismatch
Severity: Medium  
Area: content / marketing  
URL(s): Homepage  
Repro: Observe “10K TITLES AVAILABLE” vs section counts (~100–120).  
Expected: Claim matches reality or is removed.  
Actual: Inflated claim.  
Evidence: homepage screenshots + network.

### F-06 — Zero ratings on multiple titles
Severity: Medium  
Area: content  
URL(s): various movie cards  
Repro: Browse grids; see ★ 0.  
Expected: Plausible rating or “N/A”.  
Actual: Hard zero.  
Evidence: earlier page scrapes.

### F-07 — Account routes redirect when logged out (good) but full flows limited
Severity: Medium  
Area: auth  
URL(s): /watchlist, /activity, /settings, /profiles, etc.  
Repro: Visit while logged out → 307.  
Expected: Clean redirect to login (observed). Full signup/login/profile/Watch Party not fully completed without disposable mailbox control.  
Actual: Redirect works; deeper flows N/A in this session.  
Evidence: curl 307s.

### F-08 — No strong frame-ancestors / X-Frame-Options observed
Severity: Medium  
Area: security  
URL(s): HTML responses  
Repro: Check headers.  
Expected: frame-ancestors 'self' or X-Frame-Options DENY/SAMEORIGIN if not intended for embedding.  
Actual: CSP frame-src is permissive; no explicit tight frame-ancestors noted in primary headers.  
Evidence: headers.

### F-09 — Branding consistent; no “Lumina” observed
Severity: Low (positive)  
Area: visual  
Actual: “Lumovia” used consistently in UI, title, manifest.

### F-10 — robots.txt blocks many bots but allows core paths
Severity: Info  
Area: SEO  
Evidence: robots.txt content.

### Additional observations
- Manifest.json is valid (name, icons, theme_color, start_url).
- /api/health returns clean {"status":"ok",...}
- /api/search and /api/browse return large JSON result sets.
- Cookie banner present on first visit.
- Mobile bottom nav present.
- Good HSTS, nosniff, Permissions-Policy, Referrer-Policy.
