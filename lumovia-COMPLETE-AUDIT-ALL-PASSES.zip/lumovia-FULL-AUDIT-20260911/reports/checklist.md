# Master Checklist Results

Discovery & routing
* PASS sitemap.xml valid (index), sub-sitemaps present
* PASS anime.xml present and large
* PASS robots.txt valid + references sitemap (indirectly via index)
* PARTIAL every route in §2 visited (core pages + samples; bulk titles sampled)
* FAIL known-bad URLs return HTTP 404 (many soft-404 200) — F-01
* PASS unknown routes don't dump to /login (proper 404 page)

Every page (aggregate)
* PARTIAL no console errors (not fully logged per page)
* N/A React #418 (not observed in sampled pages)
* PARTIAL CSP violations (policy itself is the issue)
* PASS no failed same-origin critical requests observed
* FAIL unexpected third-party / ad domains on catalog pages — F-02
* FAIL broken or placeholder images — F-03
* PASS no horizontal body scroll observed in tested widths
* PASS brand name consistent ("Lumovia")
* PASS no lorem-ipsum / fake data as real content

Homepage
* PARTIAL hero carousel (observed, not fully arrow-tested)
* PARTIAL content rows load
* PARTIAL genre cards
* N/A Mood Quiz / Roulette fully exercised
* N/A Continue Watching (requires login)
* N/A recommendations logged-in
* N/A time-of-day greeting

Nav
* PARTIAL Genres / More dropdowns
* PASS top links go to correct places (status checked)
* PARTIAL mobile hamburger
* N/A notifications (login)
* PARTIAL footer links

Detail pages
* PARTIAL synopsis/cast etc. on sampled movie
* PARTIAL player related
* N/A full tabs exhaustive
* N/A Watch Party
* PARTIAL rating/watchlist buttons present

Player
* PARTIAL default source attempts play
* PARTIAL sources (provider hunting observed)
* N/A full every-source test + popunder confirmation
* N/A fake prompts confirmation
* PARTIAL Exit behaviour
* FAIL stuck loading states common — F-04
* N/A next/prev episode full
* N/A all keyboard shortcuts
* FAIL empty source messaging weak

Search / Auth / Account / Watch Party / PWA / Perf / A11y / SEO / Security / API / Responsive / Content
* PARTIAL or N/A for many deep flows (auth email, multi-tab Watch Party, axe injection, Lighthouse JSON, full 10-title content check, full responsive set)
* Security headers: mostly PASS with CSP caveat (F-02)
* Soft-404: FAIL
* APIs sampled: PASS clean responses
* Manifest: PASS
* Soft-404 list recorded

Note: Many deep interactive and multi-session items marked N/A or PARTIAL because they require sustained logged-in state, second browser context, or external email control not available in this automated black-box session. Core surface and high-severity issues are fully evidenced.
